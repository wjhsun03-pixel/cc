#include <stdio.h>

double average(int a, int b)
{
    double result = (a + b) / 2;
    return result;
}

int main(void)
{
    int x = 5;
    int y = 2;
    double answer;

    answer = average(x, y);

    printf("평균: %.1f\n", answer);

    return 0;
}