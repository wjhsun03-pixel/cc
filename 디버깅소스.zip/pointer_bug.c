#include <stdio.h>

void change_score(int *p)
{
    *p = 100;
}

void process_score(int *p)
{
    change_score(p);
}

int main(void)
{
    int score = 70;
    int *ptr = NULL;

    process_score(ptr);

    printf("점수: %d\n", score);

    return 0;
}