#include <stdio.h>

int main(void)
{
    int n = 5;
    int sum = 0;
    int i;

    for (i = 1; i < n; i++) {
        sum += i;
    }

    printf("1부터 %d까지의 합: %d\n", n, sum);

    return 0;
}