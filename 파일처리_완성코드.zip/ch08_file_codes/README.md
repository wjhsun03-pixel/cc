# 8장 파일 처리 - 완성된 C 예제

원본 `8장_file.pdf`의 실행 예제와 실제 동작이 있는 코드 조각을 추출하고,
누락된 부분과 오류를 보완했습니다. 각 `.c` 파일은 다른 소스 없이 독립적으로 컴파일됩니다.
본문에서 함수 원형만 소개한 항목과 시스템 구조체 선언은 별도 프로그램으로 늘리지 않았습니다.
연속된 페이지의 한 프로그램은 한 파일로 합쳤습니다. 쪽수는 PDF 기준입니다.

## 실행 환경과 컴파일

Ubuntu 등 Linux + GCC, UTF-8 소스입니다. Windows에서는 WSL의 Ubuntu에서 실행합니다.
ZIP 압축을 풀고 이 폴더에서 실행하세요.

```bash
make
./file_copy_stdio sample.txt copy_stdio.txt
./file_copy sample.txt copy_lowlevel.txt
cmp sample.txt copy_stdio.txt
cmp sample.txt copy_lowlevel.txt
```

`cmp`의 출력이 없으면 내용이 같습니다. 개별 컴파일도 가능합니다.

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic file_stat.c -o file_stat
./file_stat sample.txt
```

## 소스 목록과 실행 예

| 파일 | PDF 쪽 | 예제 내용 | 실행 예 |
|---|---:|---|---|
| `file_copy_stdio.c` | 3 | 표준 입출력 함수를 이용한 파일 복사 | `./file_copy_stdio sample.txt copy_stdio.txt` |
| `file_basic.c` | 6 | open/read/close 기본 예제 | `./file_basic sample.txt` |
| `file_open.c` | 8~9 | 파일 생성 또는 열기와 닫기 | `./file_open junk` |
| `file_check.c` | 10 | 파일 열기/닫기로 접근 가능 여부 확인 | `./file_check sample.txt` |
| `file_creat_call.c` | 13 | creat()로 빈 파일 생성 | `./file_creat_call newfile.txt` |
| `file_creat.c` | 14 | open()으로 파일 생성 및 쓰기 | `./file_creat output.txt` |
| `file_append.c` | 21 | O_APPEND로 파일 끝에 추가 | `./file_append output.txt` |
| `file_read_seq.c` | 17 | 두 번의 read()와 파일 오프셋 변화 | `./file_read_seq sample.txt` |
| `file_count.c` | 18 | read()로 파일의 바이트 수 계산 | `./file_count sample.txt` |
| `file_write_seq.c` | 20 | 두 번의 write()와 파일 오프셋 변화 | `./file_write_seq newfile` |
| `file_copy.c` | 23 | 시스템 호출 read/write를 이용한 파일 복사 | `./file_copy sample.txt copy_lowlevel.txt` |
| `file_seek_append.c` | 26 | lseek(SEEK_END) 후 파일 끝에 쓰기 | `./file_seek_append output.txt "appended text"` |
| `file_size.c` | 26~27 | lseek(SEEK_END)로 파일 크기 확인 | `./file_size sample.txt` |
| `file_hole.c` | 29 | lseek와 write로 파일의 빈 영역 생성 | `./file_hole output.txt 10` |
| `file_io.c` | 32 | 표준 입력을 표준 출력으로 복사 | `./file_io < sample.txt > result.txt` |
| `file_stderr.c` | 33 | 파일 기술자 2로 표준 오류 출력 | `./file_stderr 2> error.txt` |
| `file_output.c` | 36 | dup2()를 이용한 표준 출력 재지향 | `./file_output output.txt` |
| `file_stat.c` | 40 | lstat()로 파일 종류 확인 | `./file_stat sample.txt` |
| `file_access.c` | 43 | access()로 존재 여부와 접근 권한 검사 | `./file_access sample.txt` |
| `file_umask.c` | 46 | umask에 따른 파일 생성 권한 비교 | `./file_umask` |
| `file_dir.c` | 50 | 디렉터리 항목을 세 열로 출력 | `./file_dir .` |
| `file_chdir.c` | 56 | 작업 디렉터리 변경 전후 비교 | `./file_chdir /tmp` |
| `file_link.c` | 59~60 | 하드 링크/심볼릭 링크 생성 및 unlink | `./file_link l sample.txt hard.txt` |
| `file_rename.c` | 65~66 | rename()으로 파일 이름 변경 또는 디렉터리로 이동 | `./file_rename old.txt new.txt` |
| `filestatus.c` | 70 | fcntl(F_GETFL)로 열린 파일의 상태 확인 | `./filestatus sample.txt r` |

## 원본 대비 주요 보완

- 반환형 없는 `main()`을 `int main(...)`으로 고치고 필요한 헤더, 반환값, 인수 검사를 추가했습니다.
- PDF 3쪽과 23쪽의 두 `file_copy.c`를 `file_copy_stdio.c`와 `file_copy.c`로 구분했습니다.
- `fgetc()` 결과를 `char` 대신 `int`에 저장하고 `while (!feof(...))`를 실제 읽기 결과로 판정하도록 수정했습니다. 0xFF와 EOF도 구분합니다.
- `ssize_t`는 `%zd`, `size_t`는 `%zu`, `off_t`는 `intmax_t`로 변환하여 출력합니다.
- `read()` 오류와 EOF를 구별하고, `write()`의 부분 쓰기와 EINTR를 처리합니다. 관련 소스에 보충한 `read_retry()`/`write_all()`도 각 파일 안에 포함했습니다.
- PDF 14쪽은 문자열에 줄바꿈이 없지만 실행 결과는 16바이트입니다. 실행 결과와 맞게 `"This is a test.\n"`으로 보완했습니다.
- `file_count`는 한글 글자 수가 아닌 바이트 수를 출력합니다.
- 미초기화 상태였던 순차 쓰기 버퍼는 A 512바이트와 B 1024바이트로 채웠습니다.
- `opendir()`와 `getcwd()`는 음수 비교 대신 NULL 여부로 실패를 검사하고 `readdir()`의 끝과 오류도 구분했습니다.
- `file_hole`에 정수 유효성 검사와 오류 처리를 넣었습니다. 끝에 점 1바이트를 쓰므로 크기는 입력한 빈 영역 크기 + 1만큼 증가합니다.
- 원본의 고정 길이 작업 경로 버퍼는 동적으로 늘려 긴 경로를 처리합니다.
- `file_rename`의 메모리 할당을 검사하고, 대상이 없는 심볼릭 링크도 이동할 수 있도록 소스 검사에 `lstat()`을 사용했습니다.
- `filestatus()`에 실행용 `main()`과 r/w/rw/a 모드 선택을 보충했습니다. F_GETFL 예제이며 F_SETFL 동작을 추가하지 않았습니다.
- `file_umask`는 기존 파일의 권한과 혼동하지 않도록 새 파일만 생성합니다(O_EXCL). 실행 후 원래 umask를 복원합니다.

## 예제별 확인 방법

```bash
# 생성/추가: 첫 명령은 새 내용으로 덮어쓰기, 둘째 명령은 끝에 추가
./file_creat output.txt
./file_append output.txt
cat output.txt

# 순차 읽기: 512 + 512바이트가 실제로 읽히는 큰 파일 준비
head -c 1536 /dev/zero > big.dat
./file_read_seq big.dat
# first read = 512, second read = 512, offset = 1024

# 순차 쓰기: newfile은 아직 없어야 함
./file_write_seq newfile
wc -c newfile
# 1536바이트

# 빈 영역: 입력 파일 끝에 0바이트 10개와 점 하나 추가
./file_hole output.txt 10
od -c output.txt

# 표준 입출력과 표준 오류 분리
./file_io < sample.txt > copied.txt 2> messages.txt
cmp sample.txt copied.txt
cat messages.txt

# 하드 링크와 심볼릭 링크
cp sample.txt link_source.txt
./file_link l link_source.txt hard.txt
./file_link s link_source.txt soft.txt
ls -li link_source.txt hard.txt soft.txt
./file_stat soft.txt
./file_link u link_source.txt
cat hard.txt
# soft.txt는 대상이 사라진 링크가 됨. hard.txt의 내용은 유지됨.

# 파일 이동: 이름 변경 후 디렉터리로 이동
cp sample.txt old.txt
./file_rename old.txt new.txt
mkdir move_target
./file_rename new.txt move_target

# 생성 권한 비교: test1.txt, test2.txt가 없는 디렉터리에서 실행
./file_umask
ls -l test1.txt test2.txt
# 일반적인 기본 ACL 없는 환경에서 0666, 0600

# 열린 파일의 상태 플래그
./filestatus sample.txt r
./filestatus sample.txt a
```

`file_basic`은 인수 생략 시 `data`, `file_open`은 `junk`,
`file_count`는 `anotherfile`을 사용하여 원본의 파일 이름도 유지합니다.

## 파일이 바뀌는 예제의 동작

- `file_creat_call`, `file_creat`, `file_output`, 두 복사 프로그램은 목적지의 기존 내용을 비웁니다.
- `file_write_seq`, `file_umask`는 이름이 이미 존재하면 실패합니다. 기존 실습 파일은 직접 정리하거나 다른 이름/빈 폴더를 사용하세요.
- `file_link u`는 지정한 경로를 삭제합니다. `file_rename`은 기존 목적지 파일을 대체할 수 있습니다.
- `file_rename`은 `rename()` 학습 예제로 같은 파일시스템 안에서 사용합니다. 서로 다른 파일시스템 간 이동은 실패합니다.
- `file_seek_append`는 lseek와 write를 차례로 실행하는 예제입니다. 여러 프로세스의 동시 추가 쓰기를 조정하지 않습니다.
- `file_copy_stdio`의 같은 파일 검사는 다른 프로세스가 검사 중 경로를 바꾸지 않는 실습 환경을 가정합니다.
- `access()`와 `umask()` 결과는 실행 계정과 기본 ACL 등 환경에 따라 달라질 수 있습니다. 권한 실습은 일반 사용자로 진행하세요.

컴파일 산출물과 테스트 중 만든 데이터는 ZIP에 포함하지 않았습니다.

## 검증 결과

Ubuntu 환경의 GCC 13.3에서 25개 소스를 `-std=c11 -Wall -Wextra -Wpedantic -Werror -O2`로 모두 컴파일했습니다.
25개 프로그램을 실행해 총 165개 항목을 검증했습니다.
검증에는 바이너리/빈 파일 복사, 같은 파일·하드 링크 복사 거부, 잘못된 인수, 파일 오프셋, 빈 영역,
입출력 재지향, 긴 작업 경로, 하드/심볼릭 링크, 파일 이동과 상태 플래그 확인이 포함됩니다.
소켓 파일 생성은 실행 환경에서 허용되지 않아 소켓 종류 판별 분기의 실행 검증은 제외했습니다.
