/*
 * access()로 존재 여부와 접근 권한 검사
 * 원본: 8장_file.pdf, 43쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_access.c -o file_access
 * 실행: ./file_access sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    const int mode_array[4] = {F_OK, R_OK, W_OK, X_OK};
    const char *mode_str[4] = {"existent", "readable", "writable", "executable"};
    const char *mode_err[4] = {"Existence check", "Readability check", "Writability check", "Executability check"};
    int exists = 0;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    printf("File \"%s\" : ", argv[1]);
    for (int i = 0; i < 4; ++i) {
        if (access(argv[1], mode_array[i]) == 0) {
            printf("%s ", mode_str[i]);
            if (i == 0) exists = 1;
        } else {
            int saved_errno = errno;
            fflush(stdout);
            fprintf(stderr, "%s: %s\n", mode_err[i], strerror(saved_errno));
        }
    }
    putchar('\n');
    /* 존재하지만 실행 권한이 없는 일반 텍스트 파일도 정상 검사 결과이다.
     * 접근성 관찰 예제이며, access() 결과로 후속 open() 성공을 보장하지 않는다. */
    return exists ? EXIT_SUCCESS : EXIT_FAILURE;
}
