/*
 * open/read/close 기본 예제
 * 원본: 8장_file.pdf, 6쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_basic.c -o file_basic
 * 실행: ./file_basic sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* 신호로 중단된 read()만 다시 호출한다. */
static ssize_t read_retry(int fd, void *buf, size_t size)
{
    ssize_t n;
    do { n = read(fd, buf, size); } while (n < 0 && errno == EINTR);
    return n;
}

int main(int argc, char *argv[])
{
    char buf[1024];
    const char *path = argc == 2 ? argv[1] : "data";
    int fd;
    ssize_t nread;
    int result = EXIT_SUCCESS;
    if (argc > 2) { fprintf(stderr, "Usage: %s [filename]\n", argv[0]); return EXIT_FAILURE; }
    fd = open(path, O_RDONLY);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    nread = read_retry(fd, buf, sizeof buf);
    if (nread < 0) { perror("read"); result = EXIT_FAILURE; }
    else {
        printf("read count = %zd\n", nread);
        /* read()는 문자열 끝의 '\0'을 붙이지 않는다. 읽은 크기만 출력한다. */
        if (fwrite(buf, 1, (size_t)nread, stdout) != (size_t)nread) {
            perror("fwrite"); result = EXIT_FAILURE;
        }
    }
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    if (fflush(stdout) == EOF) { perror("fflush"); result = EXIT_FAILURE; }
    return result;
}
