/*
 * 작업 디렉터리 변경 전후 비교
 * 원본: 8장_file.pdf, 56쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_chdir.c -o file_chdir
 * 실행: ./file_chdir /tmp
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* 고정 256바이트 대신 필요한 만큼 늘려 긴 경로도 처리한다. */
static char *current_directory(void)
{
    size_t size = 256;
    for (;;) {
        char *buf = malloc(size);
        int saved_errno;
        if (buf == NULL) return NULL;
        if (getcwd(buf, size) != NULL) return buf;
        saved_errno = errno;
        free(buf);
        if (saved_errno != ERANGE) { errno = saved_errno; return NULL; }
        if (size > (size_t)-1 / 2) { errno = ENOMEM; return NULL; }
        size *= 2;
    }
}

int main(int argc, char *argv[])
{
    char *buf;
    if (argc != 2) { fprintf(stderr, "Usage: %s dirname\n", argv[0]); return EXIT_FAILURE; }
    buf = current_directory();
    if (buf == NULL) { perror("getcwd"); return EXIT_FAILURE; }
    printf("working directory (before) = %s\n", buf);
    free(buf);
    if (chdir(argv[1]) == -1) { perror("chdir"); return EXIT_FAILURE; }
    buf = current_directory();
    if (buf == NULL) { perror("getcwd"); return EXIT_FAILURE; }
    printf("working directory (after ) = %s\n", buf);
    free(buf);
    /* 자식 프로세스의 작업 디렉터리만 바뀐다. 실행한 셸의 경로는 그대로다. */
    return EXIT_SUCCESS;
}
