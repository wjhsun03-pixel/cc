/*
 * 파일 열기/닫기로 접근 가능 여부 확인
 * 원본: 8장_file.pdf, 10쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_check.c -o file_check
 * 실행: ./file_check sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int fd;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_RDONLY);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    printf("File \"%s\" found...\n", argv[1]);
    if (close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    return EXIT_SUCCESS;
}
