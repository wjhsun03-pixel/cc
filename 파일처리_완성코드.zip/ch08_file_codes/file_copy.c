/*
 * 시스템 호출 read/write를 이용한 파일 복사
 * 원본: 8장_file.pdf, 23쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_copy.c -o file_copy
 * 실행: ./file_copy sample.txt copy_lowlevel.txt
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#ifndef MAX_READ
#define MAX_READ 10  /* 원본과 같은 크기. -DMAX_READ=4096 등으로 변경할 수 있다. */
#endif
#if MAX_READ < 1
#error MAX_READ must be positive
#endif

/* 신호로 중단된 read()만 다시 호출한다. */
static ssize_t read_retry(int fd, void *buf, size_t size)
{
    ssize_t n;
    do { n = read(fd, buf, size); } while (n < 0 && errno == EINTR);
    return n;
}

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int src_fd, dst_fd;
    struct stat src_stat, dst_stat;
    char buf[MAX_READ];
    ssize_t rcnt;
    uintmax_t total = 0;
    int result = EXIT_SUCCESS;
    if (argc != 3) {
        fprintf(stderr, "Usage: %s src_file dest_file\n", argv[0]); return EXIT_FAILURE;
    }
    src_fd = open(argv[1], O_RDONLY);
    if (src_fd == -1) { perror("src open"); return EXIT_FAILURE; }
    /* O_TRUNC를 아직 쓰지 않는다. 같은 파일인지 검사한 다음 내용을 비운다. */
    dst_fd = open(argv[2], O_WRONLY | O_CREAT, 0644);
    if (dst_fd == -1) { perror("dst open"); close(src_fd); return EXIT_FAILURE; }
    if (fstat(src_fd, &src_stat) == -1 || fstat(dst_fd, &dst_stat) == -1) {
        perror("fstat"); close(src_fd); close(dst_fd); return EXIT_FAILURE;
    }
    if (src_stat.st_dev == dst_stat.st_dev && src_stat.st_ino == dst_stat.st_ino) {
        fprintf(stderr, "Source and destination are the same file.\n");
        close(src_fd); close(dst_fd); return EXIT_FAILURE;
    }
    if (!S_ISREG(src_stat.st_mode) || !S_ISREG(dst_stat.st_mode)) {
        fprintf(stderr, "This example copies regular files only.\n");
        close(src_fd); close(dst_fd); return EXIT_FAILURE;
    }
    if (ftruncate(dst_fd, 0) == -1) {
        perror("ftruncate"); close(src_fd); close(dst_fd); return EXIT_FAILURE;
    }
    while ((rcnt = read_retry(src_fd, buf, sizeof buf)) > 0) {
        if (write_all(dst_fd, buf, (size_t)rcnt) == -1) {
            perror("write"); result = EXIT_FAILURE; break;
        }
        total += (uintmax_t)rcnt;
    }
    if (rcnt < 0) { perror("read"); result = EXIT_FAILURE; }
    if (close(src_fd) == -1) { perror("close: src"); result = EXIT_FAILURE; }
    if (close(dst_fd) == -1) { perror("close: dst"); result = EXIT_FAILURE; }
    if (result == EXIT_SUCCESS) printf("total write count = %" PRIuMAX "\n", total);
    return result;
}
