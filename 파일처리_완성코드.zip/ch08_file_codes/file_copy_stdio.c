/*
 * 표준 입출력 함수를 이용한 파일 복사
 * 원본: 8장_file.pdf, 3쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_copy_stdio.c -o file_copy_stdio
 * 실행: ./file_copy_stdio sample.txt copy_stdio.txt
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    FILE *src, *dst;
    struct stat src_stat, dst_stat;
    int ch;  /* fgetc()의 결과는 EOF를 구분하기 위해 반드시 int로 받는다. */
    uintmax_t count = 0;
    int result = EXIT_SUCCESS;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s source_file destination_file\n", argv[0]);
        return EXIT_FAILURE;
    }
    src = fopen(argv[1], "rb");
    if (src == NULL) { perror("fopen: src"); return EXIT_FAILURE; }
    if (fstat(fileno(src), &src_stat) == -1) {
        perror("fstat: src"); fclose(src); return EXIT_FAILURE;
    }
    /* 같은 파일 또는 하드 링크를 목적지로 주어 원본을 비우는 실수를 막는다.
     * 이 입문 예제는 검사 중 다른 프로세스가 경로를 바꾸지 않는다고 가정한다. */
    if (stat(argv[2], &dst_stat) == 0) {
        if (src_stat.st_dev == dst_stat.st_dev && src_stat.st_ino == dst_stat.st_ino) {
            fprintf(stderr, "Source and destination are the same file.\n");
            fclose(src); return EXIT_FAILURE;
        }
    } else if (errno != ENOENT) {
        perror("stat: dst"); fclose(src); return EXIT_FAILURE;
    }
    dst = fopen(argv[2], "wb");  /* 기존 목적지 내용은 덮어쓴다. */
    if (dst == NULL) { perror("fopen: dst"); fclose(src); return EXIT_FAILURE; }

    while ((ch = fgetc(src)) != EOF) {
        if (fputc(ch, dst) == EOF) {
            perror("fputc"); result = EXIT_FAILURE; break;
        }
        ++count;
    }
    if (ferror(src)) { perror("fgetc"); result = EXIT_FAILURE; }
    if (fclose(src) == EOF) { perror("fclose: src"); result = EXIT_FAILURE; }
    /* 버퍼의 마지막 내용은 fclose()에서 기록되므로 반환값도 확인한다. */
    if (fclose(dst) == EOF) { perror("fclose: dst"); result = EXIT_FAILURE; }
    if (result == EXIT_SUCCESS) printf("copied bytes = %" PRIuMAX "\n", count);
    return result;
}
