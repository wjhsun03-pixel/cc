/*
 * read()로 파일의 바이트 수 계산
 * 원본: 8장_file.pdf, 18쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_count.c -o file_count
 * 실행: ./file_count sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define BUFSIZE 512

/* 신호로 중단된 read()만 다시 호출한다. */
static ssize_t read_retry(int fd, void *buf, size_t size)
{
    ssize_t n;
    do { n = read(fd, buf, size); } while (n < 0 && errno == EINTR);
    return n;
}

int main(int argc, char *argv[])
{
    char buffer[BUFSIZE];
    const char *path = argc == 2 ? argv[1] : "anotherfile";
    int fd;
    ssize_t nread;
    uintmax_t total = 0;
    int result = EXIT_SUCCESS;
    if (argc > 2) { fprintf(stderr, "Usage: %s [filename]\n", argv[0]); return EXIT_FAILURE; }
    fd = open(path, O_RDONLY);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    while ((nread = read_retry(fd, buffer, sizeof buffer)) > 0) total += (uintmax_t)nread;
    if (nread < 0) { perror("read"); result = EXIT_FAILURE; }
    /* UTF-8 한글 한 글자는 여러 바이트이다. 글자 수가 아니라 바이트 수이다. */
    if (result == EXIT_SUCCESS) printf("total bytes in %s: %" PRIuMAX "\n", path, total);
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
