/*
 * open()으로 파일 생성 및 쓰기
 * 원본: 8장_file.pdf, 14쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_creat.c -o file_creat
 * 실행: ./file_creat output.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    const char *buf = "This is a test.\n";
    int fd;
    int result = EXIT_SUCCESS;
    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; /* 0644 */
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_WRONLY | O_CREAT | O_TRUNC, mode);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    if (write_all(fd, buf, strlen(buf)) == -1) { perror("write"); result = EXIT_FAILURE; }
    else printf("write count = %zu\n", strlen(buf));
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
