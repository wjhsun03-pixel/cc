/*
 * creat()로 빈 파일 생성
 * 원본: 8장_file.pdf, 13쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_creat_call.c -o file_creat_call
 * 실행: ./file_creat_call newfile.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int fd;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    /* creat()는 두 인수가 모두 필수이며, 기존 파일은 길이가 0이 된다.
     * 다음과 동일: open(argv[1], O_WRONLY | O_CREAT | O_TRUNC, 0644) */
    fd = creat(argv[1], 0644);
    if (fd == -1) { perror("creat"); return EXIT_FAILURE; }
    if (close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    printf("Created/truncated: %s\n", argv[1]);
    return EXIT_SUCCESS;
}
