/*
 * 디렉터리 항목을 세 열로 출력
 * 원본: 8장_file.pdf, 50쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_dir.c -o file_dir
 * 실행: ./file_dir .
 */
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    DIR *pdir;
    struct dirent *pde;
    size_t i = 0;
    int result = EXIT_SUCCESS;
    if (argc != 2) { fprintf(stderr, "Usage: %s dirname\n", argv[0]); return EXIT_FAILURE; }
    pdir = opendir(argv[1]);
    if (pdir == NULL) { perror("opendir"); return EXIT_FAILURE; }
    for (;;) {
        errno = 0;
        pde = readdir(pdir);
        if (pde == NULL) {
            if (errno != 0) { perror("readdir"); result = EXIT_FAILURE; }
            break;
        }
        printf("%20s ", pde->d_name);
        if (++i % 3 == 0) putchar('\n');
    }
    if (i % 3 != 0) putchar('\n');
    if (closedir(pdir) == -1) { perror("closedir"); result = EXIT_FAILURE; }
    return result;
}
