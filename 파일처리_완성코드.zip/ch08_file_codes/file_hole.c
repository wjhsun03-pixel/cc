/*
 * lseek와 write로 파일의 빈 영역 생성
 * 원본: 8장_file.pdf, 29쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_hole.c -o file_hole
 * 실행: ./file_hole output.txt 10
 */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int fd;
    char *end;
    intmax_t parsed;
    off_t size, hole_size, position;
    int result = EXIT_SUCCESS;
    if (argc != 3) { fprintf(stderr, "Usage: %s filename hole_bytes\n", argv[0]); return EXIT_FAILURE; }
    errno = 0;
    parsed = strtoimax(argv[2], &end, 10);
    hole_size = (off_t)parsed;
    if (errno == ERANGE || end == argv[2] || *end != '\0' || parsed < 0 ||
        (intmax_t)hole_size != parsed) {
        fprintf(stderr, "hole_bytes must be a nonnegative integer that fits off_t.\n");
        return EXIT_FAILURE;
    }
    fd = open(argv[1], O_RDWR);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    size = lseek(fd, 0, SEEK_END);
    if (size == (off_t)-1) { perror("lseek: size"); close(fd); return EXIT_FAILURE; }
    if ((uintmax_t)size + (uintmax_t)hole_size >= (uintmax_t)INTMAX_MAX) {
        fprintf(stderr, "Requested file size is too large.\n"); close(fd); return EXIT_FAILURE;
    }
    printf("Before : %s's size = %" PRIdMAX "\n", argv[1], (intmax_t)size);
    position = lseek(fd, hole_size, SEEK_END);
    if (position == (off_t)-1) { perror("lseek: hole"); result = EXIT_FAILURE; }
    else if (write_all(fd, ".", 1) == -1) { perror("write"); result = EXIT_FAILURE; }
    else {
        size = lseek(fd, 0, SEEK_END);
        if (size == (off_t)-1) { perror("lseek: after"); result = EXIT_FAILURE; }
        else printf("After : %s's size = %" PRIdMAX "\n", argv[1], (intmax_t)size);
    }
    /* lseek만으로 파일 크기가 늘지는 않는다. 끝에 '.'을 쓰므로 H+1바이트 증가.
     * 건너뛴 H바이트는 읽으면 0이다. 실제 디스크 할당은 파일시스템에 달려 있다. */
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
