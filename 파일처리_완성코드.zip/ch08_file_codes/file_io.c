/*
 * 표준 입력을 표준 출력으로 복사
 * 원본: 8장_file.pdf, 32쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_io.c -o file_io
 * 실행: ./file_io < sample.txt > result.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#define BUFSIZE 256

/* 신호로 중단된 read()만 다시 호출한다. */
static ssize_t read_retry(int fd, void *buf, size_t size)
{
    ssize_t n;
    do { n = read(fd, buf, size); } while (n < 0 && errno == EINTR);
    return n;
}

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(void)
{
    char buf[BUFSIZE];
    ssize_t n;
    fprintf(stderr, "Here is file start.\n");
    while ((n = read_retry(STDIN_FILENO, buf, sizeof buf)) > 0) {
        if (write_all(STDOUT_FILENO, buf, (size_t)n) == -1) { perror("write"); return EXIT_FAILURE; }
    }
    if (n < 0) { perror("read"); return EXIT_FAILURE; }
    fprintf(stderr, "Here is file end.\n");
    return EXIT_SUCCESS;
}
