/*
 * 하드 링크/심볼릭 링크 생성 및 unlink
 * 원본: 8장_file.pdf, 59~60쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_link.c -o file_link
 * 실행: ./file_link l sample.txt hard.txt
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int usage(const char *program)
{
    fprintf(stderr, "Usage: %s l|link src target\n"
                    "       %s s|symlink src target\n"
                    "       %s u|unlink filename\n", program, program, program);
    return EXIT_FAILURE;
}

int main(int argc, char *argv[])
{
    if (argc < 2) return usage(argv[0]);
    if (strcmp(argv[1], "l") == 0 || strcmp(argv[1], "link") == 0) {
        if (argc != 4) return usage(argv[0]);
        if (link(argv[2], argv[3]) == -1) { perror("link"); return EXIT_FAILURE; }
    } else if (strcmp(argv[1], "s") == 0 || strcmp(argv[1], "symlink") == 0) {
        if (argc != 4) return usage(argv[0]);
        /* 상대 대상 경로는 생성된 링크가 놓인 디렉터리를 기준으로 해석된다. */
        if (symlink(argv[2], argv[3]) == -1) { perror("symlink"); return EXIT_FAILURE; }
    } else if (strcmp(argv[1], "u") == 0 || strcmp(argv[1], "unlink") == 0) {
        if (argc != 3) return usage(argv[0]);
        if (unlink(argv[2]) == -1) { perror("unlink"); return EXIT_FAILURE; }
    } else {
        return usage(argv[0]);
    }
    return EXIT_SUCCESS;
}
