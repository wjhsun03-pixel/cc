/*
 * 파일 생성 또는 열기와 닫기
 * 원본: 8장_file.pdf, 8~9쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_open.c -o file_open
 * 실행: ./file_open junk
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    const char *workfile = argc == 2 ? argv[1] : "junk";
    int fd;
    if (argc > 2) { fprintf(stderr, "Usage: %s [filename]\n", argv[0]); return EXIT_FAILURE; }
    /* O_TRUNC가 없으므로 기존 파일 내용은 유지된다. */
    fd = open(workfile, O_RDWR | O_CREAT, 0644);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    printf("Opened %s: fd = %d\n", workfile, fd);
    if (close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    return EXIT_SUCCESS;
}
