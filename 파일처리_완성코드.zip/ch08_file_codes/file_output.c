/*
 * dup2()를 이용한 표준 출력 재지향
 * 원본: 8장_file.pdf, 36쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_output.c -o file_output
 * 실행: ./file_output output.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    const char *buf = "This is a test output file.\n";
    int fd;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    if (dup2(fd, STDOUT_FILENO) == -1) { perror("dup2"); close(fd); return EXIT_FAILURE; }
    /* 처음부터 fd가 1이었다면 stdout 자체를 닫지 않아야 한다. */
    if (fd != STDOUT_FILENO && close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    if (write_all(STDOUT_FILENO, buf, strlen(buf)) == -1) { perror("write"); return EXIT_FAILURE; }
    if (close(STDOUT_FILENO) == -1) { perror("close: stdout"); return EXIT_FAILURE; }
    return EXIT_SUCCESS;
}
