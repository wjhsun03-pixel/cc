/*
 * 두 번의 read()와 파일 오프셋 변화
 * 원본: 8장_file.pdf, 17쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_read_seq.c -o file_read_seq
 * 실행: ./file_read_seq sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* 신호로 중단된 read()만 다시 호출한다. */
static ssize_t read_retry(int fd, void *buf, size_t size)
{
    ssize_t n;
    do { n = read(fd, buf, size); } while (n < 0 && errno == EINTR);
    return n;
}

int main(int argc, char *argv[])
{
    char buf1[512], buf2[512];
    ssize_t n1, n2;
    off_t offset;
    int fd;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_RDONLY);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    n1 = read_retry(fd, buf1, sizeof buf1);
    if (n1 < 0) { perror("read: first"); close(fd); return EXIT_FAILURE; }
    n2 = read_retry(fd, buf2, sizeof buf2);
    if (n2 < 0) { perror("read: second"); close(fd); return EXIT_FAILURE; }
    offset = lseek(fd, 0, SEEK_CUR);
    if (offset == (off_t)-1) { perror("lseek"); close(fd); return EXIT_FAILURE; }
    /* 실제 읽은 크기만큼 전진한다. 짧은 파일이면 두 번째 결과가 0일 수 있다. */
    printf("first read = %zd bytes\nsecond read = %zd bytes\noffset = %" PRIdMAX "\n",
           n1, n2, (intmax_t)offset);
    if (close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    return EXIT_SUCCESS;
}
