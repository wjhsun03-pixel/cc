/*
 * rename()으로 파일 이름 변경 또는 디렉터리로 이동
 * 원본: 8장_file.pdf, 65~66쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_rename.c -o file_rename
 * 실행: ./file_rename old.txt new.txt
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    struct stat src_stat, dst_stat;
    char *source, *target;
    const char *base;
    size_t len, target_len;
    int destination_is_directory = 0;
    if (argc != 3) { fprintf(stderr, "Usage: %s src target\n", argv[0]); return EXIT_FAILURE; }
    source = strdup(argv[1]);
    if (source == NULL) { perror("strdup"); return EXIT_FAILURE; }
    len = strlen(source);
    while (len > 1 && source[len - 1] == '/') source[--len] = '\0';
    /* lstat()을 사용하여 대상이 사라진 심볼릭 링크 자체도 이동할 수 있다. */
    if (lstat(source, &src_stat) == -1) { perror("lstat: src"); free(source); return EXIT_FAILURE; }
    base = strrchr(source, '/');
    base = base == NULL ? source : base + 1;
    if (*base == '\0' || strcmp(base, ".") == 0 || strcmp(base, "..") == 0) {
        fprintf(stderr, "Use a named file or directory as source.\n"); free(source); return EXIT_FAILURE;
    }
    /* stat()이므로 목적지가 디렉터리를 가리키는 심볼릭 링크여도 처리한다. */
    if (stat(argv[2], &dst_stat) == 0) destination_is_directory = S_ISDIR(dst_stat.st_mode);
    else if (errno != ENOENT) { perror("stat: target"); free(source); return EXIT_FAILURE; }
    target_len = strlen(argv[2]);
    if (destination_is_directory) {
        if (target_len > SIZE_MAX - strlen(base) - 2) {
            fprintf(stderr, "Target path is too long.\n"); free(source); return EXIT_FAILURE;
        }
        target_len += strlen(base) + 1;
    }
    target = malloc(target_len + 1);
    if (target == NULL) { perror("malloc"); free(source); return EXIT_FAILURE; }
    if (destination_is_directory) snprintf(target, target_len + 1, "%s/%s", argv[2], base);
    else memcpy(target, argv[2], target_len + 1);
    printf("source = %s\ntarget = %s\n", source, target);
    /* 같은 파일시스템 내 이동 예제이다. 기존 목적지 파일은 대체될 수 있다.
     * 파일시스템을 넘는 이동은 EXDEV로 실패하며 복사/삭제까지 구현하지 않는다. */
    if (rename(source, target) == -1) {
        perror("rename"); free(target); free(source); return EXIT_FAILURE;
    }
    free(target);
    free(source);
    return EXIT_SUCCESS;
}
