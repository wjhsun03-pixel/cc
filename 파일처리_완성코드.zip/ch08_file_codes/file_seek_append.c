/*
 * lseek(SEEK_END) 후 파일 끝에 쓰기
 * 원본: 8장_file.pdf, 26쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_seek_append.c -o file_seek_append
 * 실행: ./file_seek_append output.txt "appended text"
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int fd;
    int result = EXIT_SUCCESS;
    if (argc != 3) { fprintf(stderr, "Usage: %s existing_file text\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_RDWR); /* 원본처럼 파일이 이미 존재해야 한다. */
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    if (lseek(fd, 0, SEEK_END) == (off_t)-1) { perror("lseek"); result = EXIT_FAILURE; }
    else if (write_all(fd, argv[2], strlen(argv[2])) == -1) { perror("write"); result = EXIT_FAILURE; }
    /* lseek 후 write는 두 단계이다. 동시 추가 쓰기에는 O_APPEND가 적합하다. */
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
