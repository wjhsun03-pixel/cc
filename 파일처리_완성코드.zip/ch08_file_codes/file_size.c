/*
 * lseek(SEEK_END)로 파일 크기 확인
 * 원본: 8장_file.pdf, 26~27쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_size.c -o file_size
 * 실행: ./file_size sample.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int fd;
    off_t size;
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    fd = open(argv[1], O_RDONLY);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    size = lseek(fd, 0, SEEK_END);
    if (size == (off_t)-1) { perror("lseek"); close(fd); return EXIT_FAILURE; }
    printf("%s's size = %" PRIdMAX "\n", argv[1], (intmax_t)size);
    if (close(fd) == -1) { perror("close"); return EXIT_FAILURE; }
    return EXIT_SUCCESS;
}
