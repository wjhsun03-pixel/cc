/*
 * lstat()로 파일 종류 확인
 * 원본: 8장_file.pdf, 40쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_stat.c -o file_stat
 * 실행: ./file_stat sample.txt
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    struct stat buf;
    const char *msg = "unknown file type";
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return EXIT_FAILURE; }
    /* stat()과 달리 심볼릭 링크의 대상이 아니라 링크 자체를 조사한다. */
    if (lstat(argv[1], &buf) == -1) { perror("lstat"); return EXIT_FAILURE; }
    if (S_ISREG(buf.st_mode)) msg = "regular file";
    else if (S_ISDIR(buf.st_mode)) msg = "directory";
    else if (S_ISCHR(buf.st_mode)) msg = "character special file";
    else if (S_ISBLK(buf.st_mode)) msg = "block special file";
    else if (S_ISFIFO(buf.st_mode)) msg = "pipe or FIFO";
    else if (S_ISLNK(buf.st_mode)) msg = "symbolic link";
    else if (S_ISSOCK(buf.st_mode)) msg = "socket";
    printf("\"%s\" is %s\n", argv[1], msg);
    return EXIT_SUCCESS;
}
