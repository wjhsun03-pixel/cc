/*
 * 파일 기술자 2로 표준 오류 출력
 * 원본: 8장_file.pdf, 33쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_stderr.c -o file_stderr
 * 실행: ./file_stderr 2> error.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(void)
{
    const char msg[] = "boob\n"; /* 원본의 예시 문자열 */
    if (write_all(STDERR_FILENO, msg, sizeof msg - 1) == -1) {
        perror("write: stderr"); return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
