/*
 * umask에 따른 파일 생성 권한 비교
 * 원본: 8장_file.pdf, 46쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_umask.c -o file_umask
 * 실행: ./file_umask
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    int fd;
    int result = EXIT_FAILURE;
    mode_t old_mask = umask(0);
    /* 기존 파일에는 새 생성 권한이 적용되지 않는다. O_EXCL로 새 파일만 만든다. */
    fd = open("test1.txt", O_WRONLY | O_CREAT | O_EXCL, 0666);
    if (fd == -1) { perror("open: test1.txt"); goto restore; }
    if (close(fd) == -1) { perror("close: test1.txt"); goto restore; }
    umask(S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH); /* 0066 */
    fd = open("test2.txt", O_WRONLY | O_CREAT | O_EXCL, 0666);
    if (fd == -1) { perror("open: test2.txt"); goto restore; }
    if (close(fd) == -1) { perror("close: test2.txt"); goto restore; }
    puts("Created test1.txt (0666) and test2.txt (0600), before any default ACL effects.");
    result = EXIT_SUCCESS;
restore:
    umask(old_mask);
    return result;
}
