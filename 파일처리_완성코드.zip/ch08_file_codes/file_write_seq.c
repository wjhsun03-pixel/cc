/*
 * 두 번의 write()와 파일 오프셋 변화
 * 원본: 8장_file.pdf, 20쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic file_write_seq.c -o file_write_seq
 * 실행: ./file_write_seq newfile
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

/* write()는 요청한 바이트보다 적게 쓸 수 있으므로 나머지를 반복해서 쓴다. */
static int write_all(int fd, const void *data, size_t size)
{
    const char *p = data;
    size_t done = 0;
    while (done < size) {
        ssize_t n = write(fd, p + done, size - done);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    char header1[512], header2[1024];
    int fd;
    off_t offset;
    int result = EXIT_SUCCESS;
    if (argc != 2) { fprintf(stderr, "Usage: %s new_filename\n", argv[0]); return EXIT_FAILURE; }
    /* 원본의 미초기화 배열에 예측 가능한 실습 데이터를 채운다. */
    memset(header1, 'A', sizeof header1);
    memset(header2, 'B', sizeof header2);
    fd = open(argv[1], O_WRONLY | O_CREAT | O_EXCL, 0664);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    if (write_all(fd, header1, sizeof header1) == -1 ||
        write_all(fd, header2, sizeof header2) == -1) {
        perror("write"); result = EXIT_FAILURE;
    } else {
        offset = lseek(fd, 0, SEEK_CUR);
        if (offset == (off_t)-1) { perror("lseek"); result = EXIT_FAILURE; }
        else printf("first write = %zu\nsecond write = %zu\noffset = %" PRIdMAX "\n",
                    sizeof header1, sizeof header2, (intmax_t)offset);
    }
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
