/*
 * fcntl(F_GETFL)로 열린 파일의 상태 확인
 * 원본: 8장_file.pdf, 70쪽. 예제/코드 조각을 독립 실행형으로 보완.
 * 컴파일: gcc -std=c11 -Wall -Wextra -Wpedantic filestatus.c -o filestatus
 * 실행: ./filestatus sample.txt r
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int filestatus(int fd)
{
    int flags = fcntl(fd, F_GETFL);
    if (flags == -1) { perror("fcntl: F_GETFL"); return -1; }
    printf("File descriptor %d: ", fd);
    switch (flags & O_ACCMODE) {
    case O_WRONLY: printf("write-only"); break;
    case O_RDWR: printf("read-write"); break;
    case O_RDONLY: printf("read-only"); break;
    default: printf("unknown access mode"); break;
    }
    if (flags & O_APPEND) printf(" - append flag set");
    putchar('\n');
    return 0;
}

/* 원본에는 filestatus() 함수만 있으므로 실행용 main()을 보충했다. */
int main(int argc, char *argv[])
{
    int fd, flags;
    int result = EXIT_SUCCESS;
    if (argc != 3) {
        fprintf(stderr, "Usage: %s filename r|w|rw|a\n", argv[0]); return EXIT_FAILURE;
    }
    /* w도 O_TRUNC 없이 열어 기존 파일의 내용을 유지한다. */
    if (strcmp(argv[2], "r") == 0) flags = O_RDONLY;
    else if (strcmp(argv[2], "w") == 0) flags = O_WRONLY | O_CREAT;
    else if (strcmp(argv[2], "rw") == 0) flags = O_RDWR | O_CREAT;
    else if (strcmp(argv[2], "a") == 0) flags = O_WRONLY | O_CREAT | O_APPEND;
    else { fprintf(stderr, "Mode must be r, w, rw, or a.\n"); return EXIT_FAILURE; }
    fd = open(argv[1], flags, 0644);
    if (fd == -1) { perror("open"); return EXIT_FAILURE; }
    if (filestatus(fd) == -1) result = EXIT_FAILURE;
    if (close(fd) == -1) { perror("close"); result = EXIT_FAILURE; }
    return result;
}
